import React from 'react'
import Services from './Components/Services/Services'
import './index.css'
function App() {
    return (
        <div>
            <Services/>
        </div>
    )
}

export default App
