import React from 'react'
import './Home.css'
function Home() {
    return (
        <div className={'serviceHome'}>
            
        </div>
    )
}

export default Home
